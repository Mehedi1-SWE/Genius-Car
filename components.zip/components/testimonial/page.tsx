export default function Testimonial() {
    return (
        <div className="relative mx-auto h-[6400px] w-[1440px]">

            {/* 1st Layout - Testimonial Section */}
            <div className="absolute left-[361px] top-[5793px] h-[178px] w-[717px]">

                {/* 1st Inner Layout - Testimonial */}
                <div className="absolute left-[301px] top-[0px] h-[24px] w-[114px]">
                    <span className="block text-center font-['Inter'] text-[20px] font-bold leading-[100%] tracking-[0%] text-[#FF3811]">
                        Testimonial
                    </span>
                </div>

                {/* 2nd Inner Layout - What Customer Says */}
                <div className="absolute left-[126px] top-[44px] h-[54px] w-[464px]">
                    <span className="block text-center font-['Inter'] text-[45px] font-bold leading-[100%] tracking-[0%] text-[#151515]">
                        What Customer Says
                    </span>
                </div>

                {/* 3rd Inner Layout - Description */}
                <div className="absolute left-[0px] top-[118px] h-[60px] w-[717px]">
                    <span className="block text-center font-['Inter'] text-[16px] font-normal leading-[30px] tracking-[0%] capitalize text-[#737373]">
                        the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.
                    </span>
                </div>

            </div>

            {/* 2nd Layout - Testimonial Cards */}

            {/* Left Layout */}
            <div className="absolute left-[150px] top-[6021px] h-[349px] w-[558px] border border-[#F3F3F3]">
            </div>

            {/* Right Layout */}
            <div className="absolute left-[732px] top-[6021px] h-[349px] w-[558px] border border-[#F3F3F3]">
            </div>

        </div>
    );
}